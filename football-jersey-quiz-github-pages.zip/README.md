# Jersey IQ — Football Quiz

A responsive, single-page football jersey quiz designed for GitHub Pages.

## Publish on GitHub Pages
1. Create or open your GitHub repository.
2. Upload `index.html` to the repository's root (top level).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then click **Save**.
6. Wait for the Pages URL to appear.

No build tools, server, or database are required. Scores are saved in the player's browser using local storage.

## Features
- Player → jersey number and jersey number → player modes
- Normal, Hard, Ultra and Deadly timers
- World football and PSL player pools
- 10, 15, 20 question and endless modes
- Score, streak, accuracy and local best-score tracking
- Responsive mobile layout
- Leaving the browser tab during a round ends the round

Player numbers and squads can change between seasons. Edit the `players` array in `index.html` to update the quiz.
